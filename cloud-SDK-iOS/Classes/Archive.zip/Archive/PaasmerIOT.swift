//
//  PaasmerIOT.swift
//  paasmerSDK
//
//  Created by MOBODEX INC on 4/28/17.
//  Copyright © 2017 mobodexter. All rights reserved.
//

import Foundation
import AWSIoT

public class PaasmerIot: NSObject{
 
   public func publish(message: String, topic: String) {
        let iotModel = PaasmerIotModel()
        iotModel.connect()
      let iotDataManager = AWSIoTDataManager.default()
       iotDataManager.publishString(message, onTopic:topic, qoS:.messageDeliveryAttemptedAtLeastOnce)
    }
    public func subscribe(topic: String,callBack:@escaping (_ message: String)->()) {
        let iotModel = PaasmerIotModel()
        iotModel.connect()
       let iotManager = AWSIoTDataManager.default()
        iotManager.subscribe(toTopic: topic, qoS: .messageDeliveryAttemptedAtMostOnce, messageCallback: {
            (payload) ->Void in
            let stringValue = NSString(data: payload, encoding: String.Encoding.utf8.rawValue)!
           callBack(stringValue as String)
            
        })
    }
   public func unsubscribe(topic: String) {
        let iotModel = PaasmerIotModel()
        iotModel.connect()
        let iotManager = AWSIoTDataManager.default()
        iotManager.unsubscribeTopic(topic)

    }
}
