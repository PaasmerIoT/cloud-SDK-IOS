//
//  Const.swift
//  HiveyPie
//
//  Created by Martynets Ruslan on 01.02.17.
//  Copyright © 2017 Martynets Ruslan. All rights reserved.
//

import Foundation
import AWSCognitoIdentityProvider

struct Const {
  
  struct awsCognito {
    static let CognitoIdentityUserPoolRegion: AWSRegionType = .USWest2
    static let CognitoIdentityUserPoolId = "us-west-2_b339S7Ecl"
    static let CognitoIdentityUserPoolAppClientId = "1duc9lgdu5doi1mo22d3nm7h3g"
    static let CognitoIdentityUserPoolAppClientSecret = "19fk68lap39udp2udh524u1js7h12cprnnar0kuq9k3m0nsg8mkh"
    static let AWSCognitoUserPoolsSignInProviderKey = "UserPool"
  }
  
  struct awsIot {
//    static let 
    static let CognitoIdentityPoolId = "us-west-2:768fb06c-963b-4dc8-8c91-401ab0ecb621"
    static let CertificateSigningRequestCommonName = "dexter"
    static let CertificateSigningRequestCountryName = "dexter"
    static let CertificateSigningRequestOrganizationName = "dexter"
    static let CertificateSigningRequestOrganizationalUnitName = "dexter"
    static let PolicyName = "dexterpie-policy"

  }
  
  struct userDefaults {
    static let lockScreenPassword = "lockScreenPassword"
    static let awsIotCertificateId = "awsIotCertificateId"
    static let awsIotCertificateArn = "awsIotCertificateArn"
  }
  
  static let lockScreenPasswordNumbers = 4
  static let serverUrl = "http://ec2-52-41-46-86.us-west-2.compute.amazonaws.com/"
  
  struct coreData {
    static let User = "User"
    static let Device = "Device"
  }
  
    struct notificationCenter {
        static let iotConnectionWatcher = "iotConnectionWatcher"
    }
}
