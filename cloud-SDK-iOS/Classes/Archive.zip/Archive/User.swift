//
//  User.swift
//  HiveyPie
//
//  Created by Martynets Ruslan on 01.02.17.
//  Copyright © 2017 Martynets Ruslan. All rights reserved.
//

import Foundation
import AWSCognitoIdentityProvider

class User {
  
 
  static let instance = User()
  
   
  // MARK: - Private properties
  private var pool: AWSCognitoIdentityUserPool
  
  // MARK: - Public properties
  var currentUser: AWSCognitoIdentityUser?
  
  var isSignedIn: Bool {
    return isExists ? currentUser!.isSignedIn : false
  }
  
  var isExists: Bool {
    return currentUser != nil ? true : false
  }
  
  // MARK: - Public methods
  func setCurrentUser() {
    currentUser = pool.currentUser()
  }
  
  func logOut() {
    currentUser?.signOut()
  }
  
  fileprivate init() {
    // setup service configuration
    let serviceConfiguration = AWSServiceConfiguration(region: Const.awsCognito.CognitoIdentityUserPoolRegion, credentialsProvider: nil)
    
    // create pool configuration
    let poolConfiguration = AWSCognitoIdentityUserPoolConfiguration(clientId: Const.awsCognito.CognitoIdentityUserPoolAppClientId,
                                                                    clientSecret: Const.awsCognito.CognitoIdentityUserPoolAppClientSecret,
                                                                    poolId: Const.awsCognito.CognitoIdentityUserPoolId)
    
    // initialize user pool client
    AWSCognitoIdentityUserPool.register(with: serviceConfiguration, userPoolConfiguration: poolConfiguration, forKey: Const.awsCognito.AWSCognitoUserPoolsSignInProviderKey)
    
    // fetch the user pool client we initialized in above step
    pool = AWSCognitoIdentityUserPool(forKey: Const.awsCognito.AWSCognitoUserPoolsSignInProviderKey)
    
    
   
    
  }
  
  
  
}
